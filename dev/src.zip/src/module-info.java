module src {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.desktop;


    opens com.uk.ac.aber.cs221.gp17.app to javafx.fxml;
    exports com.uk.ac.aber.cs221.gp17.app.main.java;
    exports com.uk.ac.aber.cs221.gp17.app.main.java.UIControllers;
    opens com.uk.ac.aber.cs221.gp17.app.main.java.UIControllers to javafx.fxml;
    exports com.uk.ac.aber.cs221.gp17.app.main.java.Pieces;
    opens com.uk.ac.aber.cs221.gp17.app.main.java.Pieces to javafx.fxml, com.google.gson;
    opens com.uk.ac.aber.cs221.gp17.app.main.java.Enums to com.google.gson;
}