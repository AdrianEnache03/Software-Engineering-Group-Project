package com.uk.ac.aber.cs221.gp17.app.main.java.Enums;

public enum PieceName {
    PAWN("p"),
    KNIGHT("kn"),
    BISHOP("b"),
    ROOK("r"),
    KING("k"),
    QUEEN("q");

    private final String label;

    PieceName(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
