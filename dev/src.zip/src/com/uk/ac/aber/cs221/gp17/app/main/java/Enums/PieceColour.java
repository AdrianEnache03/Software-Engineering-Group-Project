package com.uk.ac.aber.cs221.gp17.app.main.java.Enums;

public enum PieceColour {
    BLACK("b"),
    WHITE("w");


    private final String label;

    PieceColour(String label) {
        this.label = label;
    }

    public String getColourLabel() {
        return label;
    }
}
